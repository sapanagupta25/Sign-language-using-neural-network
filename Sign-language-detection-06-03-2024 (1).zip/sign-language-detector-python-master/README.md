# sign-language-detector-python

Sign language detector with Python, OpenCV and Mediapipe !

[![Watch the video](https://img.youtube.com/vi/MJCSjXepaAM/0.jpg)](https://www.youtube.com/watch?v=MJCSjXepaAM)
